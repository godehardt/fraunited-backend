#!/bin/sh
./start 127.0.0.1 . 1 &
sleep 2
./start 127.0.0.1 . 2  &
sleep 0.3
./start 127.0.0.1 . 3  &
sleep 0.3
./start 127.0.0.1 . 4  &
sleep 0.3
./start 127.0.0.1 . 5  &
sleep 0.3
./start 127.0.0.1 . 6  &
sleep 0.3
./start 127.0.0.1 . 7  &
sleep 0.3
./start 127.0.0.1 . 8  &
sleep 0.3
./start 127.0.0.1 . 9  &
sleep 0.3
./start 127.0.0.1 . 10 &
sleep 0.3
./start 127.0.0.1 . 11 &
sleep 0.3
./start 127.0.0.1 . 12 &

