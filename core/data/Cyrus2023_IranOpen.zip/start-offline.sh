#!/bin/sh

./start.sh --offline-client-mode --debug --debug-server-logging ${1+"$@"}

